@extends('layouts.app')

@section('content')
<!DOCTYPE html>
<html lang="en">
<head>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <style>
        .table{
            margin-top: 10%;
        }
    </style>
</head>
<body>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1 text-center">
            <div class="panel panel-default">
                <div class="panel-heading">
                @if(auth()->user() && auth()->user()->id == $post->user_id)
                <br><a href="../edit/{{ $post->id }}">
                <i class="fa fa-btn fa-pencil"></i>Uredi post
                </a>
                @endif
                </div>
                <div class="panel-body">
                    <article>
                        <h2>{{ $post->name }}</h2>
                        <h4>{{ $post->description }}</h4>
                        <br>
                        <p> Slika: </p>
                        <img width="400" src="{{ asset('uploads/' . $post->image) }}" />
                    </article>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
@endsection