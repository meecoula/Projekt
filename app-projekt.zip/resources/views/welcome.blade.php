@extends('layouts.app')

@section('content')
<!DOCTYPE html>
<html lang="en">
<head>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <style>
            .full-height {
                height: 500px;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }


            .content {
                text-align: center;
            }

            .title {
                font-size: 84px;
            }

            .m-b-md {
                margin-bottom: 30px;
            }
    </style>
</head>
<body>
        <div class="flex-center position-ref full-height">

            <div class="content">
                <h1 style="opacity:0.8;color:purple" class="title m-b-md">Algebra Web Development</h1>
                <h2 style="opacity:0.6;color:purple;">Završni projekt back-end</h2>

            </div>
        </div>
</body>
</html>
@endsection