<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html lang="en">
<head>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <style>
        .table{
            margin-top: 10%;
        }
    </style>
</head>
<body>
<div class="container table-responsive">
    <table class="table table-striped table-hover">
        <thead class="thead-dark">
        <th>ID</th>
        <th>Ime</th>
        <th>Edit</th>
        <th>Obriši</th>
        <th>Post u meniju</th>
        <th>Obriši post iz menija</th>
        <?php ($user = Auth::user()); ?>
        </thead>
        <tbody>
        <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <div><?php echo e($menu->id); ?></div>
                </td>
                <td>
                    <div><?php echo e($menu->name); ?></div>
                </td>
                <td>
                    <form action="<?php echo e(url('menus/edit/' . $menu->id)); ?>" method="GET" >
                        <?php echo e(csrf_field()); ?>

                        <button type="submit" class="btn btn-primary"><i class="fa fa-btn fa-edit"></i>Uredi</button>
                    </form>
                </td>

                <td>
                <form action="<?php echo e(url('menus/' . $menu->id)); ?>" method="POST" >
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('DELETE')); ?>

                        <button type="submit" class="btn btn-danger"><i class="fa fa-btn fa-edit"></i>Obriši</button>
                    </form>
                </td>
                <td>
                    <?php $__currentLoopData = $menu->posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menuPost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div>
                        <a  class="btn btn-xs btn-info pull-right" href="<?php echo e(url('posts/details/'.$menuPost->id)); ?>"><?php echo e($menuPost->pivot->name); ?></a>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
                <td>
                    <?php $__currentLoopData = $menu->posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menuPost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div>
                        <form class="d-inline" action="<?php echo e(url('deletePost/'.$menu->id .'/'. $menuPost->id)); ?>" method="POST" >
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field('DELETE')); ?>

                            <button type="submit" class="btn btn-warning"><i class="fa fa-btn fa-edit"></i>Obriši post iz menija</button>
                        </form>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php if($user->role != null && $user->role->id == 1): ?>
        <a class="btn btn-xs btn-info pull-right" href="<?php echo e(route('newMenu')); ?>">Novi meni</a>

        <a class="btn btn-xs btn-info pull-right" href="<?php echo e(route('addPostToMenu')); ?>">Novi post u meni</a>
    <?php endif; ?>
</div>
</body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\app2\resources\views/menus.blade.php ENDPATH**/ ?>