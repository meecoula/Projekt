

<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html lang="en">
<head>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <style>
        .table{
            margin-top: 10%;
        }
    </style>
</head>
<body>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1 text-center">
            <div class="panel panel-default">
                <div class="panel-heading">
                <?php if(auth()->user() && auth()->user()->id == $post->user_id): ?>
                <br><a href="../edit/<?php echo e($post->id); ?>">
                <i class="fa fa-btn fa-pencil"></i>Uredi post
                </a>
                <?php endif; ?>
                </div>
                <div class="panel-body">
                    <article>
                        <h2><?php echo e($post->name); ?></h2>
                        <h4><?php echo e($post->description); ?></h4>
                        <br>
                        <p> Slika: </p>
                        <img width="400" src="<?php echo e(asset('uploads/' . $post->image)); ?>" />
                    </article>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\app2\resources\views/postView.blade.php ENDPATH**/ ?>