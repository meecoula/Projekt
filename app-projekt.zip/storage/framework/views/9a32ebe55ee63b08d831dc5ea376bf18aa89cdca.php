<?php $__env->startSection('content'); ?>
    <!DOCTYPE html>
<html lang="en">
<head>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <style>
        .table{
            margin-top: 10%;
        }
    </style>
</head>
<body>
<form class="container col-md-4 col-md-offset-4" method="POST" action="<?php echo e(route('menus')); ?>">
    <?php echo csrf_field(); ?>
    <div class="form-group">
        <label for="croatian_title">Ime novog menua:  </label>
        <input class="form-control" type="text" name="name" id="name" required>
    </div>
    <button type="submit" class="btn btn-primary">Pošalji</button>
</form>
</body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\app2\resources\views/newmenu.blade.php ENDPATH**/ ?>