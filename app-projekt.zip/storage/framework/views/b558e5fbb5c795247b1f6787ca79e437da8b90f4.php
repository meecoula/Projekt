

<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html lang="en">
<head>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <style>
        .table{
            margin-top: 10%;
        }
    </style>
</head>
<body>
    <div class="container table-responsive">
        <table class="table table-striped table-hover">
            <thead class="thead-dark">
                <th>ID</th>
                <th>Ime</th>
                <th></th>
                <th></th>
            </thead>
            <tbody>
            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <div><?php echo e($role->id); ?></div>
                    </td>
                    <td>
                        <div><?php echo e($role->name); ?></div>
                    </td>
                    <td>
                        <form action="<?php echo e(url('role/edit/' . $role->id)); ?>" method="GET">
                            <?php echo e(csrf_field()); ?>

                            <button type="submit" class="btn btn-primary"><i class="fa fa-btn fa-edit"></i>Uredi</button>
                        </form>
                    </td>
                    <td>
                        <form action="<?php echo e(url('role/' . $role->id)); ?>" method="POST">
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field('DELETE')); ?>

                            <button type="submit" class="btn btn-danger"><i class="fa fa-btn fa-edit"></i>Obriši</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <a class="btn btn-xs btn-info pull-right" href="<?php echo e(route('newRole')); ?>">Nova uloga</a>
    </div>
</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\app\resources\views/roles.blade.php ENDPATH**/ ?>