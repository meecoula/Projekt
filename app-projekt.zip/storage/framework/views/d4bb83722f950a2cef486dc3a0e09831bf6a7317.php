<?php $__env->startSection('content'); ?>
    <!DOCTYPE html>
<html lang="en">
<head>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <style>
        .table{
            margin-top: 10%;
        }
    </style>
</head>
<body>
<form action="<?php echo e(url('savePost')); ?>" method="POST" class="container col-md-4 col-md-offset-4">
    <?php echo e(csrf_field()); ?>

    <div class="form-group">
        <label for="croatian_title">Name: </label>
        <input class="form-control" type="text" name="name" id="name" required>
    </div>
    
    <div class="form-group">
        <label for="croatian_title">Order: </label>
        <input class="form-control" type="text" name="order" id="order" required>
    </div>
    
    <div class="form-group">
        <label for="menu_id">Menus: </label>
        <select class="form-control" name="menu_id" id="menu_id">
            <option disabled>Chose menu</option>
                              
           <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($menu->id); ?>"> <?php echo e($menu->name); ?> </option>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                
        </select>
    </div>
    
    <div class="form-group">
    <label for="post_id">Posts: </label>
        <select class="form-control" name="post_id" id="post_id">
            <option disabled>Chose post</option>
                              
           <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($post->id); ?>"> <?php echo e($post->name); ?> </option>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                
        </select>
    </div>
    <button type="submit" class="btn btn-primary">Pošalji</button>
</form>
</body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\app2\resources\views/menuPostEdit.blade.php ENDPATH**/ ?>